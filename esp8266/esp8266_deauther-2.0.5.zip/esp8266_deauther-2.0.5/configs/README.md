Here you find a bunch of modified config files for different boards.  
Those are meant to be copy and replaced in the Arduino sektch.  

The default config should be fine for all boards that don't have a display or a RGB LED (like the NodeMCU).  